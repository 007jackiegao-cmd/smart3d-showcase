import {defineConfig} from 'vite';
export default defineConfig({base:'./',build:{sourcemap:false,rollupOptions:{output:{entryFileNames:'app.js',chunkFileNames:'chunk-[name].js',assetFileNames:'[name][extname]'}}}});
